# 李铭轩的学术主页

基于 [luost26/academic-homepage](https://github.com/luost26/academic-homepage) 的 Jekyll 学术主页。
第一版包含首页、研究项目、论文栏目和在线简历。英文为主，姓名和研究方向中英并列。

## 编辑内容

| 内容 | 文件 |
| --- | --- |
| 姓名、邮箱、简介、教育经历、经历、奖项 | `_data/profile.yml` |
| 研究方向与项目介绍 | `_data/research.yml` |
| 导航栏 | `_data/navigation.yml` |
| 论文 | `_publications/*.md` |
| 新增栏目的布局与移动端样式 | `assets/css/personal.css` |
| 网站描述与网址 | `_config.yml` |

待核对的信息见 `CONTENT_CHECKLIST.md`。原始简历不在网站目录中。

头像：将照片存入 `assets/images/portrait.jpg`，然后在 `_data/profile.yml` 中设置 `portrait_url: /assets/images/portrait.jpg`。
学术链接：Google Scholar 填完整链接，GitHub 填用户名，ORCID 填标识符；空值时隐藏。

## 本地预览

安装 Ruby 和 Bundler 后，在网站目录运行：

```sh
bundle config set --local path vendor/bundle
bundle install
bundle exec jekyll serve --host 127.0.0.1 --port 4000
```

打开 http://127.0.0.1:4000 。修改配置后需重启；修改内容数据会自动重新生成。
生成静态网站：`bundle exec jekyll build`，结果在 `_site/`。
页面样式和导航脚本使用本地文件，预览不依赖外部字体或脚本服务。

## 发布到 GitHub Pages

1. 建立你自己的仓库，通常命名为 `你的用户名.github.io`。
2. 上传此项目，在仓库 Settings → Pages 中将 Source 设为 GitHub Actions。
3. 将 `_config.yml` 的 `url` 设置为正式网址（例如 `https://你的用户名.github.io`）。
4. 推送到 `master`，或手动运行 Build and deploy academic homepage 工作流。

工作流会根据 Pages 配置自动传入子路径，也适用于普通项目仓库。
远程仓库为 `Li-Mingxuan/Li-Mingxuan.github.io`。GitHub 上通过 `academic-homepage.zip` 保存当前 Jekyll 源码，发布工作流解压后构建。旧版模板文件保留在远程仓库中，不参与当前网站构建。

当前本地目录仍以模板仓库为 `upstream`；后续修改本地源码后，需要重新打包并更新远程的 `academic-homepage.zip`。实际发布工作流的本地副本位于 `.local/github-upload/pages.yml`。不要将个人内容推送到模板作者仓库。

## 模板与许可

保留原项目 MIT 许可证和页脚来源链接，详见 `UPSTREAM.md`。
