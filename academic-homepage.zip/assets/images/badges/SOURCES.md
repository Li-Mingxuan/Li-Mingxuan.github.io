# Education emblems

These marks identify the universities listed in the education section. Rights remain with the respective universities. The source artwork is retained without recoloring or distortion.

- **Harbin Engineering University** (`heu.png`): https://en.wikipedia.org/wiki/File:Harbin_Engineering_University_logo.png ; the file identifies the original source as the university's English website. Asset: https://upload.wikimedia.org/wikipedia/en/7/7a/Harbin_Engineering_University_logo.png . Official identity reference: https://dwxcb.hrbeu.edu.cn/xxwhbsywhcp/main.psp . The official download server was unavailable during this update.
- **University of Warwick** (`warwick.svg`): official crest asset linked from https://warwick.ac.uk/ . Asset: https://d36jn9qou1tztq.cloudfront.net/static_war/render/id7/images/crest-dynamic.svg.481631441674 . A light color scheme is applied to the image element to use its supplied positive variant on the white card.
- **Beijing University of Posts and Telecommunications** (`bupt.png`): official visual identity website https://vi.bupt.edu.cn/ ; asset: https://vi.bupt.edu.cn/images/ls1-icn1.png . Identity reference: https://vi.bupt.edu.cn/jcxt/xhgf.htm .
