document.addEventListener('DOMContentLoaded', function () {
  const toggle = document.querySelector('.navbar-toggler');
  const menu = document.getElementById('navbarResponsive');
  if (!toggle || !menu) return;
  function closeMenu() { menu.classList.remove('show'); toggle.setAttribute('aria-expanded', 'false'); }
  toggle.addEventListener('click', function () {
    toggle.setAttribute('aria-expanded', String(menu.classList.toggle('show')));
  });
  menu.addEventListener('click', function (event) { if (event.target.closest('a')) closeMenu(); });
  document.addEventListener('keydown', function (event) {
    if (event.key === 'Escape' && menu.classList.contains('show')) { closeMenu(); toggle.focus(); }
  });
});
