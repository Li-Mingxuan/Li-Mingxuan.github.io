# Icons

GitHub, ORCID and LinkedIn icons are from Font Awesome Free 6.5.1, https://github.com/FortAwesome/Font-Awesome/tree/6.5.1/svgs/brands . SVG icons licensed under CC BY 4.0; original notices retained in each file. https://fontawesome.com/license/free
