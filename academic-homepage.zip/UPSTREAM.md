# Template provenance

- Original project: https://github.com/luost26/academic-homepage
- Starting commit: 7bd10b6af57d52fd74ba1dd0e0f5aa4b6419c97e
- License: MIT (retained in LICENSE)
- Retained Jekyll data/include/layout structure and Bootstrap-based sidebar/card layout.
- Customized personal content, navigation, research/CV pages, typography, local assets and deployment workflow.
- Original demonstration pages and collections are excluded or cleared to prevent sample people, papers and news from appearing on the personal site.
